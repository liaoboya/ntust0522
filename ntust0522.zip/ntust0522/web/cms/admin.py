from django.contrib import admin
from .models import Introduction

# Register your models here.

class RestaurantAdmin(admin.ModelAdmin):
	list_display = ('name', 'email', 'detail')
	
admin.site.register(Introduction)